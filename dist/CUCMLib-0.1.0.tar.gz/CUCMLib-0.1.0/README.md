# CUCMLib

CUCM ile etkileşim için bir kütüphane

## Installation

Use the package manager [pip](https://pip.pypa.io/en/stable/) to install CUCMLib.

```bash
pip install CUCMLib
```

## License

[MIT](https://choosealicense.com/licenses/mit/)