from .phone import *
from .partition import *



def help():
    print("""
          
          
          Ana dosyanın help'i düzenlenecek
          
          
          """)